import { ScrollView, Text, View, Pressable, Alert, FlatList, Modal, TextInput } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { Card } from "@/components/ui/card";
import { RoutineSchedule } from "@/components/ui/routine-schedule";
import { useState } from "react";

export default function RotinaScreen() {
  const [selectedDay, setSelectedDay] = useState("Segunda");
  
  const [routineTasks] = useState([
    { day: "Segunda", timeStart: "06h", timeEnd: "07h", activity: "Acordar" },
    { day: "Segunda", timeStart: "07h", timeEnd: "07:15", activity: "Tomar café" },
    { day: "Segunda", timeStart: "07:15", timeEnd: "07:30", activity: "Tomar banho" },
    { day: "Segunda", timeStart: "07:30", timeEnd: "09:00", activity: "Varrer Casa" },
    { day: "Segunda", timeStart: "09:00", timeEnd: "11h", activity: "Aula De Excel" },
    { day: "Segunda", timeStart: "11h", timeEnd: "11:40", activity: "Almoçar, Banho" },
    { day: "Segunda", timeStart: "11:40", timeEnd: "13h", activity: "Ir Para o eco" },
    { day: "Segunda", timeStart: "13h", timeEnd: "17h", activity: "EcoSocial Senac" },
    { day: "Segunda", timeStart: "17h", timeEnd: "18:30", activity: "Ir Para Casa" },
    { day: "Segunda", timeStart: "18:30", timeEnd: "18:45", activity: "Tomar Banho" },
    { day: "Segunda", timeStart: "18:45", timeEnd: "19h", activity: "Jantar" },
    { day: "Segunda", timeStart: "19h", timeEnd: "20h", activity: "Afazeres de Casa" },
    { day: "Segunda", timeStart: "20h", timeEnd: "21h", activity: "Programação" },
    { day: "Segunda", timeStart: "21h", timeEnd: "06h", activity: "Dormir" },

    { day: "Terça", timeStart: "06h", timeEnd: "07h", activity: "Acordar" },
    { day: "Terça", timeStart: "07h", timeEnd: "07:15", activity: "Tomar café" },
    { day: "Terça", timeStart: "07:15", timeEnd: "07:30", activity: "Tomar banho" },
    { day: "Terça", timeStart: "07:30", timeEnd: "09:00", activity: "Lavar a Pia" },
    { day: "Terça", timeStart: "09:00", timeEnd: "11h", activity: "Aula De Excel" },
    { day: "Terça", timeStart: "11h", timeEnd: "11:40", activity: "Almoçar, Banho" },
    { day: "Terça", timeStart: "11:40", timeEnd: "13h", activity: "Ir Para o eco" },
    { day: "Terça", timeStart: "13h", timeEnd: "17h", activity: "EcoSocial Senac" },
    { day: "Terça", timeStart: "17h", timeEnd: "18:30", activity: "Ir Para Casa" },
    { day: "Terça", timeStart: "18:30", timeEnd: "18:45", activity: "Tomar Banho" },
    { day: "Terça", timeStart: "18:45", timeEnd: "19h", activity: "Jantar" },
    { day: "Terça", timeStart: "19h", timeEnd: "20h", activity: "Afazeres de Casa" },
    { day: "Terça", timeStart: "20h", timeEnd: "21h", activity: "Programação" },
    { day: "Terça", timeStart: "21h", timeEnd: "06h", activity: "Dormir" },

    { day: "Quarta", timeStart: "06h", timeEnd: "07h", activity: "Acordar" },
    { day: "Quarta", timeStart: "07h", timeEnd: "07:15", activity: "Tomar café" },
    { day: "Quarta", timeStart: "07:15", timeEnd: "07:30", activity: "Tomar banho" },
    { day: "Quarta", timeStart: "07:30", timeEnd: "09:00", activity: "Limpar o fogão" },
    { day: "Quarta", timeStart: "09:00", timeEnd: "11h", activity: "Aula De Excel" },
    { day: "Quarta", timeStart: "11h", timeEnd: "11:40", activity: "Almoçar, Banho" },
    { day: "Quarta", timeStart: "11:40", timeEnd: "13h", activity: "Ir Para o eco" },
    { day: "Quarta", timeStart: "13h", timeEnd: "17h", activity: "EcoSocial Senac" },
    { day: "Quarta", timeStart: "17h", timeEnd: "18:30", activity: "Ir Para Casa" },
    { day: "Quarta", timeStart: "18:30", timeEnd: "18:45", activity: "Tomar Banho" },
    { day: "Quarta", timeStart: "18:45", timeEnd: "19h", activity: "Jantar" },
    { day: "Quarta", timeStart: "19h", timeEnd: "20h", activity: "Afazeres de Casa" },
    { day: "Quarta", timeStart: "20h", timeEnd: "21h", activity: "Programação" },
    { day: "Quarta", timeStart: "21h", timeEnd: "06h", activity: "Dormir" },

    { day: "Quinta", timeStart: "06h", timeEnd: "07h", activity: "Acordar" },
    { day: "Quinta", timeStart: "07h", timeEnd: "07:15", activity: "Tomar café" },
    { day: "Quinta", timeStart: "07:15", timeEnd: "07:30", activity: "Tomar banho" },
    { day: "Quinta", timeStart: "07:30", timeEnd: "09:00", activity: "Pano nos Moveis" },
    { day: "Quinta", timeStart: "09:00", timeEnd: "11h", activity: "Aula De Excel" },
    { day: "Quinta", timeStart: "11h", timeEnd: "11:40", activity: "Almoçar, Banho" },
    { day: "Quinta", timeStart: "11:40", timeEnd: "13h", activity: "Ir Para o eco" },
    { day: "Quinta", timeStart: "13h", timeEnd: "17h", activity: "EcoSocial Senac" },
    { day: "Quinta", timeStart: "17h", timeEnd: "18:30", activity: "Ir Para Casa" },
    { day: "Quinta", timeStart: "18:30", timeEnd: "18:45", activity: "Tomar Banho" },
    { day: "Quinta", timeStart: "18:45", timeEnd: "19h", activity: "Jantar" },
    { day: "Quinta", timeStart: "19h", timeEnd: "20h", activity: "Afazeres de Casa" },
    { day: "Quinta", timeStart: "20h", timeEnd: "21h", activity: "Programação" },
    { day: "Quinta", timeStart: "21h", timeEnd: "06h", activity: "Dormir" },

    { day: "Sexta", timeStart: "06h", timeEnd: "07h", activity: "Acordar" },
    { day: "Sexta", timeStart: "07h", timeEnd: "07:15", activity: "Tomar café" },
    { day: "Sexta", timeStart: "07:15", timeEnd: "07:30", activity: "Tomar banho" },
    { day: "Sexta", timeStart: "07:30", timeEnd: "09:00", activity: "Lavar os Tenis, Sapatos..." },
    { day: "Sexta", timeStart: "09:00", timeEnd: "11h", activity: "Aula de Excel" },
    { day: "Sexta", timeStart: "11h", timeEnd: "11:40", activity: "Almoço" },
    { day: "Sexta", timeStart: "11:40", timeEnd: "13h", activity: "Ir Para o Eco" },
    { day: "Sexta", timeStart: "13h", timeEnd: "17h", activity: "EcoSocial" },
    { day: "Sexta", timeStart: "17h", timeEnd: "18:30", activity: "Ir Para o barracão" },
    { day: "Sexta", timeStart: "18:30", timeEnd: "18:45", activity: "Afazeres do Barracão" },

    { day: "Sabado", timeStart: "06h", timeEnd: "07h", activity: "Acordar No barracão" },
    { day: "Sabado", timeStart: "07h", timeEnd: "14h", activity: "Afazeres do barracão" },
    { day: "Sabado", timeStart: "14h", timeEnd: "14:30", activity: "Voltar Para casa" },
    { day: "Sabado", timeStart: "14:30", timeEnd: "17h", activity: "Descanso" },
    { day: "Sabado", timeStart: "17h", timeEnd: "18:30", activity: "Aula de Excel" },
    { day: "Sabado", timeStart: "18:30", timeEnd: "18:45", activity: "Pausa" },
    { day: "Sabado", timeStart: "18:45", timeEnd: "20:30", activity: "Voltar a Estudar" },
    { day: "Sabado", timeStart: "20:30", timeEnd: "21h", activity: "Jantar" },
    { day: "Sabado", timeStart: "21h", timeEnd: "21:15", activity: "Tomar Banho" },
    { day: "Sabado", timeStart: "21:15", timeEnd: "21:45", activity: "Descanso" },
    { day: "Sabado", timeStart: "21:45", timeEnd: "06h", activity: "Dormir" },

    { day: "Domingo", timeStart: "06h", timeEnd: "07h", activity: "Acordar" },
    { day: "Domingo", timeStart: "07h", timeEnd: "07:15", activity: "Tomar café" },
    { day: "Domingo", timeStart: "07:15", timeEnd: "07:30", activity: "Tomar Banho" },
    { day: "Domingo", timeStart: "07:30", timeEnd: "10:30", activity: "Descanso" },
    { day: "Domingo", timeStart: "10:30", timeEnd: "12h", activity: "Leitura" },
    { day: "Domingo", timeStart: "12h", timeEnd: "13h", activity: "Almoçar, livre" },
    { day: "Domingo", timeStart: "13h", timeEnd: "15h", activity: "Programação" },
    { day: "Domingo", timeStart: "15h", timeEnd: "15:30", activity: "Pausa" },
    { day: "Domingo", timeStart: "15:30", timeEnd: "17h", activity: "Voltar a Estudar" },
    { day: "Domingo", timeStart: "17h", timeEnd: "19:30", activity: "Descanso" },
    { day: "Domingo", timeStart: "19:30", timeEnd: "20h", activity: "Dar Uma Volta" },
    { day: "Domingo", timeStart: "20h", timeEnd: "21:30", activity: "Jantar" },
    { day: "Domingo", timeStart: "21:30", timeEnd: "22h", activity: "Descanso" },
    { day: "Domingo", timeStart: "22h", timeEnd: "06h", activity: "Dormir" },
  ]);

  const [showImportModal, setShowImportModal] = useState(false);

  const handleImportExcel = () => {
    Alert.alert(
      "Importar Rotina",
      "Arquivo de rotina carregado com sucesso! Cronograma semanal atualizado.",
      [{ text: "OK", onPress: () => setShowImportModal(false) }]
    );
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-4">
          {/* Header */}
          <View className="gap-1">
            <Text className="text-2xl font-bold text-foreground">Rotina</Text>
            <Text className="text-sm text-muted">Seu cronograma semanal</Text>
          </View>

          {/* Import Button */}
          <Pressable
            onPress={() => setShowImportModal(true)}
            className="px-4 py-3 bg-primary/10 rounded-lg items-center border border-primary"
            style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
          >
            <Text className="text-sm font-semibold text-primary">📅 Importar Rotina Excel</Text>
          </Pressable>

          {/* Routine Schedule */}
          <RoutineSchedule tasks={routineTasks} selectedDay={selectedDay} />

          {/* Info Card */}
          <Card className="p-4 gap-2 border-l-4 border-primary">
            <Text className="text-xs font-semibold text-muted uppercase">Dica</Text>
            <Text className="text-sm text-foreground">
              Siga o cronograma para manter a produtividade e alcançar seus objetivos diários!
            </Text>
          </Card>
        </View>
      </ScrollView>

      {/* Import Modal */}
      <Modal visible={showImportModal} transparent animationType="fade" onRequestClose={() => setShowImportModal(false)}>
        <View className="flex-1 bg-black/50 items-center justify-center p-4">
          <Card className="w-full gap-4 p-6">
            <View className="gap-1">
              <Text className="text-xl font-bold text-foreground">📅 Importar Rotina</Text>
              <Text className="text-sm text-muted">Selecione a planilha para importar</Text>
            </View>

            <View className="gap-2">
              <Pressable
                onPress={() => {
                  handleImportExcel();
                }}
                className="px-4 py-3 bg-primary/10 rounded-lg border border-primary"
                style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
              >
                <Text className="text-sm font-semibold text-primary">Rotina Atualizada (Carregada)</Text>
              </Pressable>

              <Pressable
                onPress={() => Alert.alert("Info", "Selecione um arquivo Excel do seu dispositivo")}
                className="px-4 py-3 bg-surface rounded-lg border border-border"
                style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
              >
                <Text className="text-sm font-semibold text-foreground">Escolher Outro Arquivo</Text>
              </Pressable>
            </View>

            <View className="flex-row gap-2">
              <Pressable
                onPress={() => setShowImportModal(false)}
                className="flex-1 px-4 py-3 bg-surface rounded-lg items-center border border-border"
                style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
              >
                <Text className="text-sm font-semibold text-foreground">Cancelar</Text>
              </Pressable>
              <Pressable
                onPress={() => {
                  Alert.alert("Sucesso", "Rotina importada com sucesso!");
                  setShowImportModal(false);
                }}
                className="flex-1 px-4 py-3 bg-primary rounded-lg items-center"
                style={({ pressed }) => ({ opacity: pressed ? 0.8 : 1 })}
              >
                <Text className="text-sm font-semibold text-background">Importar</Text>
              </Pressable>
            </View>
          </Card>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
