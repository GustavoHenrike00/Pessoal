import { View, Text, Pressable, ScrollView, Dimensions } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useRouter } from "expo-router";
import { useState } from "react";

const { height } = Dimensions.get("window");

export default function OnboardingScreen() {
  const router = useRouter();
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: "Bem-vindo ao Smart Life",
      subtitle: "Gustavo H.",
      description: "Gerencie sua vida em um só lugar",
      icon: "🎯",
      color: "#22C55E",
    },
    {
      title: "Suas Finanças",
      subtitle: "Sob Controle",
      description: "Visualize e acompanhe suas transações em tempo real",
      icon: "💰",
      color: "#22C55E",
    },
    {
      title: "Sua Agenda",
      subtitle: "Organizada",
      description: "Nunca mais perca um compromisso importante",
      icon: "📅",
      color: "#22C55E",
    },
    {
      title: "Notícias",
      subtitle: "Sempre Atualizado",
      description: "Fique informado sobre tecnologia, economia e mais",
      icon: "📰",
      color: "#22C55E",
    },
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      router.replace("/(tabs)");
    }
  };

  const handleSkip = () => {
    router.replace("/(tabs)");
  };

  const slide = slides[currentSlide];

  return (
    <ScreenContainer containerClassName="bg-background" className="justify-between">
      <View className="flex-1 justify-center items-center gap-8 px-6">
        {/* Icon */}
        <View className="w-24 h-24 rounded-full items-center justify-center" style={{ backgroundColor: `${slide.color}20` }}>
          <Text className="text-6xl">{slide.icon}</Text>
        </View>

        {/* Title */}
        <View className="gap-2 items-center">
          <Text className="text-sm font-semibold text-primary uppercase tracking-widest">
            {slide.subtitle}
          </Text>
          <Text className="text-4xl font-bold text-foreground text-center leading-tight">
            {slide.title}
          </Text>
        </View>

        {/* Description */}
        <Text className="text-base text-muted text-center leading-relaxed">
          {slide.description}
        </Text>
      </View>

      {/* Indicators and Buttons */}
      <View className="gap-4 pb-8">
        {/* Indicators */}
        <View className="flex-row justify-center gap-2">
          {slides.map((_, index) => (
            <View
              key={index}
              className={`h-2 rounded-full ${
                index === currentSlide ? "w-8 bg-primary" : "w-2 bg-border"
              }`}
            />
          ))}
        </View>

        {/* Buttons */}
        <View className="gap-3">
          <Pressable
            onPress={handleNext}
            className="w-full py-4 rounded-lg items-center"
            style={{ backgroundColor: slide.color }}
          >
            <Text className="text-base font-semibold text-white">
              {currentSlide === slides.length - 1 ? "Começar" : "Próximo"}
            </Text>
          </Pressable>

          {currentSlide < slides.length - 1 && (
            <Pressable onPress={handleSkip} className="w-full py-3 items-center">
              <Text className="text-base font-semibold text-muted">Pular</Text>
            </Pressable>
          )}
        </View>
      </View>
    </ScreenContainer>
  );
}
