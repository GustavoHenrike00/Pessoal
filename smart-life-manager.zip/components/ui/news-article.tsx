import { View, Text, Image, Pressable, Share } from "react-native";
import { Card } from "./card";
import type { NewsArticle } from "@/lib/news-service";

export interface NewsArticleProps {
  article: NewsArticle;
  onPress?: () => void;
}

export function NewsArticleCard({ article, onPress }: NewsArticleProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("pt-BR", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `${article.title}\n\n${article.url}`,
        title: article.title,
        url: article.url,
      });
    } catch (error) {
      console.error("Error sharing:", error);
    }
  };

  return (
    <Pressable onPress={onPress}>
      <Card className="mb-3 overflow-hidden">
        {article.urlToImage && (
          <Image
            source={{ uri: article.urlToImage }}
            className="w-full h-40 bg-surface"
          />
        )}
        <View className="p-3 gap-2">
          <Text className="text-xs text-muted uppercase font-semibold">
            {article.source.name}
          </Text>
          <Text className="text-sm font-bold text-foreground leading-tight">
            {article.title}
          </Text>
          {article.description && (
            <Text className="text-xs text-muted line-clamp-2">
              {article.description}
            </Text>
          )}
          <View className="flex-row items-center justify-between pt-2 border-t border-border">
            <Text className="text-xs text-muted">
              {formatDate(article.publishedAt)}
            </Text>
            <Pressable
              onPress={handleShare}
              className="px-3 py-1 rounded bg-primary/10"
            >
              <Text className="text-xs font-semibold text-primary">
                Compartilhar
              </Text>
            </Pressable>
          </View>
        </View>
      </Card>
    </Pressable>
  );
}
