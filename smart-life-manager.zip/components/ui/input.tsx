import { TextInput, View, Text, type TextInputProps } from "react-native";
import { cn } from "@/lib/utils";

export interface InputProps extends TextInputProps {
  label?: string;
  error?: string;
  containerClassName?: string;
}

export function Input({
  label,
  error,
  containerClassName,
  className,
  ...props
}: InputProps) {
  return (
    <View className={containerClassName}>
      {label && (
        <Text className="text-sm font-semibold text-foreground mb-2">
          {label}
        </Text>
      )}
      <TextInput
        className={cn(
          "bg-surface border border-border rounded-lg px-4 py-3 text-foreground",
          error && "border-error",
          className
        )}
        placeholderTextColor="#999"
        {...props}
      />
      {error && (
        <Text className="text-xs text-error mt-1">
          {error}
        </Text>
      )}
    </View>
  );
}
