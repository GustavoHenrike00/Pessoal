import { View, Text, TextInput, Pressable, Modal, Alert } from "react-native";
import { useState } from "react";
import { Card } from "./card";
import { useColors } from "@/hooks/use-colors";

interface SecretNotesProps {
  isOpen?: boolean;
  onClose?: () => void;
  onSave?: (content: string, password: string) => Promise<void>;
  initialContent?: string;
}

export function SecretNotes({
  isOpen = false,
  onClose,
  onSave,
  initialContent = "",
}: SecretNotesProps) {
  const colors = useColors();
  const [step, setStep] = useState<"password" | "notes">("password");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [notes, setNotes] = useState(initialContent);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSetPassword = () => {
    if (!password || !confirmPassword) {
      Alert.alert("Erro", "Preencha ambos os campos de senha");
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert("Erro", "As senhas não correspondem");
      return;
    }

    if (password.length < 4) {
      Alert.alert("Erro", "A senha deve ter pelo menos 4 caracteres");
      return;
    }

    setStep("notes");
  };

  const handleSave = async () => {
    setIsLoading(true);
    try {
      await onSave?.(notes, password);
      Alert.alert("Sucesso", "Notas salvas com segurança");
      setNotes("");
      setPassword("");
      setConfirmPassword("");
      setStep("password");
      onClose?.();
    } catch (error) {
      Alert.alert("Erro", "Falha ao salvar notas");
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setNotes("");
    setPassword("");
    setConfirmPassword("");
    setStep("password");
    onClose?.();
  };

  return (
    <Modal visible={isOpen} animationType="slide" transparent>
      <View className="flex-1 bg-black/50 justify-end">
        <View className="bg-background rounded-t-3xl p-6 gap-4" style={{ maxHeight: "90%" }}>
          {/* Header */}
          <View className="flex-row items-center justify-between">
            <Text className="text-2xl font-bold text-foreground">🔐 Notas Secretas</Text>
            <Pressable onPress={handleClose} className="p-2">
              <Text className="text-2xl">✕</Text>
            </Pressable>
          </View>

          {step === "password" ? (
            // Password Setup
            <View className="gap-4">
              <Text className="text-sm text-muted">
                Crie uma senha para proteger suas notas importantes
              </Text>

              <View className="gap-2">
                <Text className="text-xs font-semibold text-muted uppercase">Senha</Text>
                <View className="flex-row items-center gap-2 px-4 py-3 bg-surface rounded-lg border border-border">
                  <TextInput
                    className="flex-1 text-foreground"
                    placeholder="Digite a senha"
                    placeholderTextColor={colors.muted}
                    secureTextEntry={!showPassword}
                    value={password}
                    onChangeText={setPassword}
                  />
                  <Pressable onPress={() => setShowPassword(!showPassword)}>
                    <Text className="text-lg">{showPassword ? "👁️" : "👁️‍🗨️"}</Text>
                  </Pressable>
                </View>
              </View>

              <View className="gap-2">
                <Text className="text-xs font-semibold text-muted uppercase">Confirmar Senha</Text>
                <View className="flex-row items-center gap-2 px-4 py-3 bg-surface rounded-lg border border-border">
                  <TextInput
                    className="flex-1 text-foreground"
                    placeholder="Confirme a senha"
                    placeholderTextColor={colors.muted}
                    secureTextEntry={!showPassword}
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                  />
                </View>
              </View>

              <Pressable
                onPress={handleSetPassword}
                className="px-4 py-3 bg-primary rounded-lg items-center"
              >
                <Text className="text-base font-semibold text-background">Continuar</Text>
              </Pressable>
            </View>
          ) : (
            // Notes Editor
            <View className="gap-4 flex-1">
              <Text className="text-sm text-muted">
                Escreva suas notas importantes aqui (protegidas por senha)
              </Text>

              <TextInput
                className="flex-1 p-4 bg-surface rounded-lg border border-border text-foreground"
                placeholder="Digite suas notas..."
                placeholderTextColor={colors.muted}
                multiline
                value={notes}
                onChangeText={setNotes}
                textAlignVertical="top"
              />

              <View className="flex-row gap-2">
                <Pressable
                  onPress={() => setStep("password")}
                  className="flex-1 px-4 py-3 bg-surface rounded-lg border border-border items-center"
                >
                  <Text className="text-base font-semibold text-foreground">Voltar</Text>
                </Pressable>

                <Pressable
                  onPress={handleSave}
                  disabled={isLoading}
                  className="flex-1 px-4 py-3 bg-primary rounded-lg items-center"
                  style={{ opacity: isLoading ? 0.5 : 1 }}
                >
                  <Text className="text-base font-semibold text-background">
                    {isLoading ? "Salvando..." : "Salvar"}
                  </Text>
                </Pressable>
              </View>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
}
