import { View, Text, ScrollView, Pressable } from "react-native";
import { Card } from "./card";

interface WeekEvent {
  id: number;
  title: string;
  date: string;
  time: string;
  category: string;
  color: string;
}

interface WeekViewProps {
  events?: WeekEvent[];
  onEventPress?: (eventId: number) => void;
}

export function WeekView({ events = [], onEventPress }: WeekViewProps) {
  const getDayName = (date: Date) => {
    return date.toLocaleDateString("pt-BR", { weekday: "short" });
  };

  const getDayNumber = (date: Date) => {
    return date.getDate();
  };

  // Get next 7 days
  const weekDays = Array.from({ length: 7 }).map((_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i);
    return date;
  });

  const eventsByDay = weekDays.map((day) => {
    const dayString = day.toDateString();
    return events.filter((event) => new Date(event.date).toDateString() === dayString);
  });

  return (
    <View className="gap-4">
      <Text className="text-sm font-semibold text-muted uppercase">Próximos 7 dias</Text>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} className="gap-2">
        <View className="flex-row gap-2">
          {weekDays.map((day, index) => (
            <View key={index} className="gap-2">
              <Card className="items-center justify-center w-16 h-16 p-2">
                <Text className="text-xs font-semibold text-muted">
                  {getDayName(day).toUpperCase()}
                </Text>
                <Text className="text-lg font-bold text-foreground">
                  {getDayNumber(day)}
                </Text>
                {eventsByDay[index].length > 0 && (
                  <View className="mt-1 px-2 py-0.5 bg-primary rounded-full">
                    <Text className="text-xs font-semibold text-background">
                      {eventsByDay[index].length}
                    </Text>
                  </View>
                )}
              </Card>
            </View>
          ))}
        </View>
      </ScrollView>

      {/* Events list */}
      {events.length > 0 ? (
        <View className="gap-2">
          {events.map((event) => (
            <Pressable
              key={event.id}
              onPress={() => onEventPress?.(event.id)}
              style={({ pressed }) => ({
                opacity: pressed ? 0.7 : 1,
              })}
            >
              <Card className="flex-row items-center gap-3 p-3" style={{ borderLeftWidth: 4, borderLeftColor: event.color }}>
                <View className="flex-1">
                  <Text className="text-sm font-semibold text-foreground">{event.title}</Text>
                  <View className="flex-row items-center gap-2 mt-1">
                    <Text className="text-xs text-muted">🕐 {event.time}</Text>
                    <Text className="text-xs text-muted">• {event.category}</Text>
                  </View>
                </View>
                <Text className="text-lg text-muted">›</Text>
              </Card>
            </Pressable>
          ))}
        </View>
      ) : (
        <Card className="p-4 items-center gap-2">
          <Text className="text-2xl">📭</Text>
          <Text className="text-sm text-muted">Nenhum evento esta semana</Text>
        </Card>
      )}
    </View>
  );
}
