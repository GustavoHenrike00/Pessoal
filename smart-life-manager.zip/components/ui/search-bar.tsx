import { View, TextInput, Pressable } from "react-native";
import { useState } from "react";
import { useColors } from "@/hooks/use-colors";

interface SearchBarProps {
  placeholder?: string;
  onSearch?: (text: string) => void;
  onClear?: () => void;
}

export function SearchBar({ placeholder = "Buscar...", onSearch, onClear }: SearchBarProps) {
  const [text, setText] = useState("");
  const colors = useColors();

  const handleClear = () => {
    setText("");
    onClear?.();
  };

  const handleChangeText = (newText: string) => {
    setText(newText);
    onSearch?.(newText);
  };

  return (
    <View className="flex-row items-center gap-2 px-4 py-3 bg-surface rounded-lg border border-border">
      <View className="text-lg text-muted">🔍</View>
      <TextInput
        className="flex-1 text-foreground"
        placeholder={placeholder}
        placeholderTextColor={colors.muted}
        value={text}
        onChangeText={handleChangeText}
      />
      {text && (
        <Pressable onPress={handleClear} className="p-1">
          <View className="text-lg">✕</View>
        </Pressable>
      )}
    </View>
  );
}
