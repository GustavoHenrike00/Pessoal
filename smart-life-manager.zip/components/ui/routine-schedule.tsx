import { View, Text, ScrollView, FlatList } from "react-native";
import { Card } from "./card";

interface RoutineItem {
  day: string;
  timeStart: string;
  timeEnd: string;
  activity: string;
}

interface RoutineScheduleProps {
  tasks: RoutineItem[];
  selectedDay?: string;
}

export function RoutineSchedule({ tasks, selectedDay = "Segunda" }: RoutineScheduleProps) {
  const filteredTasks = tasks.filter((t) => t.day === selectedDay);

  const dayColors: Record<string, string> = {
    Segunda: "bg-blue-100",
    Terça: "bg-purple-100",
    Quarta: "bg-pink-100",
    Quinta: "bg-orange-100",
    Sexta: "bg-green-100",
    Sabado: "bg-yellow-100",
    Domingo: "bg-red-100",
  };

  const timeToMinutes = (time: string): number => {
    const match = time.match(/(\d+)h/);
    return match ? parseInt(match[1]) * 60 : 0;
  };

  const sortedTasks = [...filteredTasks].sort(
    (a, b) => timeToMinutes(a.timeStart) - timeToMinutes(b.timeStart)
  );

  return (
    <ScrollView showsVerticalScrollIndicator={false} className="gap-4">
      {/* Day Selector */}
      <View className="gap-2">
        <Text className="text-xs font-semibold text-muted uppercase">Dia da Semana</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} className="gap-2">
          {["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sabado", "Domingo"].map((day) => (
            <Card
              key={day}
              className={`px-4 py-2 ${selectedDay === day ? "bg-primary" : "bg-surface"}`}
            >
              <Text
                className={`text-xs font-semibold ${
                  selectedDay === day ? "text-background" : "text-foreground"
                }`}
              >
                {day.slice(0, 3)}
              </Text>
            </Card>
          ))}
        </ScrollView>
      </View>

      {/* Timeline */}
      <View className="gap-3">
        <Text className="text-sm font-semibold text-foreground">
          Cronograma - {selectedDay}
        </Text>

        {sortedTasks.length > 0 ? (
          sortedTasks.map((task, index) => (
            <Card key={index} className="p-4 gap-2 border-l-4 border-primary">
              <View className="gap-1">
                <Text className="text-xs font-semibold text-primary">
                  {task.timeStart}
                  {task.timeEnd ? ` - ${task.timeEnd}` : ""}
                </Text>
                <Text className="text-sm font-semibold text-foreground">
                  {task.activity}
                </Text>
              </View>
            </Card>
          ))
        ) : (
          <Card className="p-4 items-center">
            <Text className="text-sm text-muted italic">
              Nenhuma atividade agendada
            </Text>
          </Card>
        )}
      </View>

      {/* Summary */}
      <Card className="p-4 gap-2">
        <Text className="text-xs font-semibold text-muted uppercase">Resumo do Dia</Text>
        <Text className="text-sm text-foreground">
          Total de atividades: <Text className="font-bold">{sortedTasks.length}</Text>
        </Text>
        <Text className="text-xs text-muted mt-2">
          Dica: Siga o cronograma para manter a produtividade!
        </Text>
      </Card>
    </ScrollView>
  );
}
